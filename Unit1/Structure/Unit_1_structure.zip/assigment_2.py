print("Bienvenido a la Universidad LMFC")
print("Introduzca los datos")

Nombre = str(input("Escribe tu nombre: "))
Telefono = int(input("Escribe tu telefono: "))
correo = str(input("Escribe tu correo: "))
curso = str(input("Escribe su curso: "))

print(f'{Nombre},has elegido el {curso} como tu curso')