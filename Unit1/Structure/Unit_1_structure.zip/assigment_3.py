number_data = [323, 209, 5900, 31092, 3402, 39803, 78341, 79843740, 895, 6749, 2870984] 

print('El numero mas grande es: ', max(number_data))